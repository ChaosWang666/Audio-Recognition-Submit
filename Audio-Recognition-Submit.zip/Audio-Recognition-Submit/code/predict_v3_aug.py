# -*- coding: utf-8 -*-
import os
import numpy as np
import pandas as pd

os.environ['CUDA_VISIBLE_DEVICES'] = '0'
from fastai.vision import *
from fastai.vision.models import *
from argparse import ArgumentParser

parser = ArgumentParser()

parser.add_argument('--time', dest='time', default=5)

args = parser.parse_args()
time = args.time

SEED = 2019


def seed_everything(seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True


seed_everything(SEED)
base_dir=os.path.abspath('..')

path = datapath4file(base_dir+'/user_data/melspec_aug/{}s'.format(time))

data = ImageDataBunch.from_folder(path, size=223, train='train', valid='train',
                                  test=base_dir+'/user_data/melspec_aug/{}s/test'.format(time), bs=64)
data.normalize(imagenet_stats)

test = ImageList.from_folder(base_dir+'/user_data/melspec_aug/{}s/test'.format(time))
print(len(test))

learn = load_learner(base_dir+'/user_data/models/', file='{}sB_eff_aug.pkl'.format(time))
learn.data = data
learn.to_fp32()
# preds, _ = learn.TTA(ds_type=DatasetType.Test)
preds, _ = learn.get_preds(ds_type=DatasetType.Test)
classes = learn.data.classes
print(classes)
# print(preds.numpy())
np.save(base_dir+"/prediction_result/{}sBpreds_aug.npz".format(time), preds.numpy())
results = ['' for x in range(preds.shape[0])]
for i in np.arange(preds.shape[0]):
    # results[i] = preds[i].numpy()
    # results[i] = str(results[i][0]) + ',' + str(results[i][1])
    results[i] = classes[np.argmax(preds[i]).numpy()]
ids = [item.name[:-4] for item in learn.data.test_ds.items]
df = pd.DataFrame({'id': ids, 'label': results})
# df = pd.DataFrame(results, ids,columns=['id','label'])
print(df.head())

result_csv_path=base_dir+'/prediction_result/result_{}sB_aug.csv'.format(time)
print("result_csv_path:",result_csv_path)
df.to_csv(result_csv_path, index=None)
