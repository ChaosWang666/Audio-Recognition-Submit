# -*- coding: utf-8 -*-
"""
@author: quincyqiang
@software: PyCharm
@file: split_aug_test.py
@time: 2020/10/7 22:32
@description：
"""
import random
from pydub import AudioSegment
import librosa
import os
from tqdm import tqdm
from argparse import ArgumentParser
import os
import sys
import warnings
from argparse import ArgumentParser

import pandas as pd
from pydub import AudioSegment
from pydub.utils import make_chunks
from tqdm import tqdm
if not sys.warnoptions:
    warnings.simplefilter("ignore")
warnings.filterwarnings("ignore", category=DeprecationWarning)
random.seed(1)

parser=ArgumentParser()
parser.add_argument('--time', dest='time', default=5)
parser.add_argument('--train', dest='train', action='store_true')
#parser.add_argument('--trainB', dest='trainB', action='store_true')
parser.add_argument('--test', dest='test', action='store_true')
#parser.add_argument('--testB', dest='testB', action='store_true')
args=parser.parse_args()
time=args.time
time=int(time)
train = args.train
#trainB = args.trainB
test = args.test
#testB = args.testB

   
def get_second_part_wav(main_wav_path, part_wav_path,ran_ch=False,duration=3):
    """
    音频切片，获取部分音频，单位秒
    :param main_wav_path: 原音频文件路径
    :param start_time: 截取的开始时间
    :param end_time: 截取的结束时间
    :param part_wav_path: 截取后的音频路径
    :return:
    """
    dur = librosa.get_duration(filename=main_wav_path)
    slices = [i for i in range(1, int(dur) - duration)]
    if ran_ch:
    	slices = random.sample(slices, 70)
    for i, t in enumerate(slices):
        start_time = t * 1000
        end_time = (t + duration) * 1000

        sound = AudioSegment.from_mp3(main_wav_path)
        word = sound[start_time:end_time]

        word.export(part_wav_path.format(i), format="wav")



root_dir=os.path.abspath('..')

base_dir=root_dir+'/user_data/aug_data/'
if not os.path.exists(base_dir):
    os.mkdir(base_dir)
if not os.path.exists(base_dir+'train'):
    os.mkdir(base_dir+'train')
if not os.path.exists(base_dir+'test'):
    os.mkdir(base_dir+'test')

base_train=root_dir+'/user_data/aug_data/train/{}s/'.format(int(time))
base_test=root_dir+'/user_data/aug_data/test/{}s/'.format(int(time))

if not os.path.exists(base_train):
	os.mkdir(base_train)
if not os.path.exists(base_test):
	os.mkdir(base_test)

#train_dir = root_dir+'/data/train/'
#for wav in tqdm(os.listdir(train_dir)):
#	if wav.endswith('.wav'):
#	    main_wav_path = train_dir + wav
#	    part_wav_path = base_train + wav.replace('.wav', '') + '_chunk{}.wav'
#	    get_second_part_wav(main_wav_path, part_wav_path,True,time)


test_dir = root_dir+'/data/test/'
for wav in tqdm(os.listdir(test_dir)):
	if wav.endswith('.wav'):
	    main_wav_path = test_dir + wav
	    part_wav_path = base_test + wav.replace('.wav', '') + '_chunk{}.wav'
	    get_second_part_wav(main_wav_path, part_wav_path,False,time)
