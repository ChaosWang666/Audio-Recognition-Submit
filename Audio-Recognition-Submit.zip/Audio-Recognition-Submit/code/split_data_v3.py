# -*- coding: utf-8 -*-
import os
import sys
import warnings
from argparse import ArgumentParser

import pandas as pd
from pydub import AudioSegment
from pydub.utils import make_chunks
from tqdm import tqdm

if not sys.warnoptions:
    warnings.simplefilter("ignore")
warnings.filterwarnings("ignore", category=DeprecationWarning)

root_dir=os.path.abspath('..')
# ......./Audio-Recognition-Submit

label_train = pd.read_csv(root_dir+"/data/train/train.txt", sep=" ")

test_files = [f for f in os.listdir(root_dir+"/data/test") if f[-3:] == "wav"]
train_files = [f for f in os.listdir(root_dir+"/data/train") if f[-3:] == "wav"]
idx_spreak = {n: i for n, i in enumerate(label_train["Speaker_ID"].unique())}
spreak_idx = {i: n for n, i in enumerate(label_train["Speaker_ID"].unique())}

base_dir=root_dir+'/user_data/split_data/'
if not os.path.exists(base_dir):
    os.mkdir(base_dir)
if not os.path.exists(base_dir+'train'):
    os.mkdir(base_dir+'train')
if not os.path.exists(base_dir+'test'):
    os.mkdir(base_dir+'test')
#if not os.path.exists(base_dir+'testB'):
#    os.mkdir(base_dir+'testB')

#if not os.path.exists(base_dir+'trainB'):
#    os.mkdir(base_dir+'trainB')


base_train=root_dir+'/user_data/split_data/train/'
base_test=root_dir+'/user_data/split_data/test/'
#base_testB='data/split_data/testB/'
#base_trainB='data/split_data/trainB/'

def split_data(files_path, time=5,type="train"):
    files = [f for f in os.listdir(files_path) if f[-3:] == "wav"]
    for f in tqdm(files):
        chunk_length_ms = time*1000  # 分块的毫秒数
        print(chunk_length_ms)
        myaudio = AudioSegment.from_file(files_path + f, "wav")
        chunks = make_chunks(myaudio, chunk_length_ms)  # 将文件切割成1秒每块
        for i, chunk in tqdm(enumerate(chunks)):
            if type == "train":
                if not os.path.exists(base_train+'{}s'.format(time)):
                    os.mkdir(base_train+'{}s'.format(time))
                chunk_name = base_train+"{}s/{}_chunk{}.wav".format(time,f.replace(".wav", ""), i)
            elif type=='trainB':
                if not os.path.exists(base_trainB+'{}s'.format(time)):
                    os.mkdir(base_trainB+'{}s'.format(time))
                chunk_name = base_trainB+"{}s/{}_chunk{}.wav".format(time,f.replace(".wav", ""), i)

            elif type=='test':
                if not os.path.exists(base_test+'{}s'.format(time)):
                    os.mkdir(base_test+'{}s'.format(time))
                chunk_name = base_test+"{}s/{}_chunk{}.wav".format(time,f.replace(".wav", ""), i)
            else:
                if not os.path.exists(base_testB+'{}s'.format(time)):
                    os.mkdir(base_testB+'{}s'.format(time))
                chunk_name = base_testB+"{}s/{}_chunk{}.wav".format(time,f.replace(".wav", ""), i)
            print(chunk_name)
            chunk.export(chunk_name, format="wav")



if __name__ == '__main__':
    parser=ArgumentParser()
    parser.add_argument('--time', dest='time', default=5)
    parser.add_argument('--train', dest='train', action='store_true')
    #parser.add_argument('--trainB', dest='trainB', action='store_true')
    parser.add_argument('--test', dest='test', action='store_true')
    #parser.add_argument('--testB', dest='testB', action='store_true')
    args=parser.parse_args()
    time=args.time
    time=int(time)
    train = args.train
    #trainB = args.trainB
    test = args.test
    #testB = args.testB

    if train:
        split_data(root_dir+"/data/train/",time, type="train")
    if test:
        split_data(root_dir+"/data/test/", time,type="test")
    #if testB:
    #    split_data('./data/testB/',time,type='testB')
    #if trainB:
    #    split_data('./data/trainB/',time,type='trainB')
