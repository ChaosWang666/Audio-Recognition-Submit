import os
import numpy as np
import pandas as pd
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
from fastai.vision import *
from fastai.vision.models.wrn import wrn_22
from fastai.vision.models import *
from torchvision.models import *
import pretrainedmodels
from efficientnet_pytorch import EfficientNet
from argparse import ArgumentParser


SEED = 2019
def seed_everything(seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True
seed_everything(SEED)

parser = ArgumentParser()
parser.add_argument('--time', dest='time', default=5)
args = parser.parse_args()
time = args.time

base_dir=os.path.abspath('..')
path = datapath4file(base_dir+'/'+'user_data/melspec_aug/{}s'.format(time))
print(path)

def get_data(sz, bs):
    tfms = get_transforms(flip_vert=False, max_rotate=10, p_affine=1., p_lighting=1.,
                          max_lighting=0.7, max_zoom=1.5, max_warp=0.1)
    data = ImageDataBunch.from_folder(path, size=sz, train='train', valid='train', 
                                      test=base_dir+'/'+'user_data/melspec_aug/{}s/test'.format(time), bs=bs)
    data.normalize(imagenet_stats)
    return data


data = get_data(223, 64)
print(data.c)
arch = EfficientNet.from_pretrained('efficientnet-b4', num_classes=data.c)
learn = Learner(data, arch, metrics=accuracy)
learn = learn.split([learn.model._conv_stem, learn.model._blocks, learn.model._conv_head]).mixup()
learn.to_fp16()
learn.lr_find()

# 训练模型
print("traing model...")
classes = learn.data.classes
print(classes)
learn.fit_one_cycle(12, max_lr=(1e-5,1e-4,1e-3), wd=(1e-4,1e-3,0.2))

model_path=base_dir+'/user_data/models/{}sB_eff_aug.pkl'.format(time)
learn.export(model_path)

test_path=base_dir+'/user_data/melspec_aug/{}s/test'.format(time)
test = ImageList.from_folder(test_path)
print(len(test))


# 预测结果
print("result predicting...")
learn.to_fp32()
preds, _ = learn.get_preds(ds_type=DatasetType.Test)
classes = learn.data.classes
prob_path=base_dir+''
np.save(base_dir+"/prediction_result/{}sBpreds_aug.npz".format(time), preds.numpy())
results = ['' for x in range(preds.shape[0])]
for i in np.arange(preds.shape[0]):
    results[i] = classes[np.argmax(preds[i]).numpy()]
ids = [item.name[:-4] for item in learn.data.test_ds.items]
df = pd.DataFrame({'id': ids, 'label': results})
print(df.head())
df.to_csv(base_dir+'/prediction_result/{}sBresult_aug.csv'.format(time), index=None)
