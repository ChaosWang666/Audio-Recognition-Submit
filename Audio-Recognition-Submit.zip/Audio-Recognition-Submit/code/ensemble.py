# -*- coding: utf-8 -*-
"""
@author: quincyqiang
@software: PyCharm
@file: ensemble.py
@time: 2020/10/11 22:40
@description：
"""
import numpy as np
import pandas as pd

ai_label = ['0', '1', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '2', '20', '21', '22', '23', '24',
            '25', '26', '27', '28', '29', '3', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '4', '40',
            '41', '42', '43', '44', '45', '46', '47', '48', '49', '5', '50', '51', '52', '6', '7', '8', '9']
ai_dic = {}
for index, label in enumerate(ai_label):
    ai_dic[index] = int(label)

prob3 = np.load("result/3sBpreds.npz.npy")
prob3 = pd.DataFrame(prob3)
res3 = pd.read_csv('result/result_3sB.csv')
res3['id'] = res3['id'].apply(lambda x: x.split('_')[0] + '.wav')
prob3['id'] = res3['id']

for col in range(53):
    # prob3['{}_mean'.format(col)]=prob3.groupby('id')[col].transform('mean')
    # del prob3[col]
    prob3[col] = prob3.groupby('id')[col].transform('mean')

prob3 = prob3.drop_duplicates(subset='id')
prob3 = prob3.sort_values(by='id').reset_index(drop=True)

prob2 = np.load("result/2sBpreds.npz.npy")
prob2 = pd.DataFrame(prob2)
res2 = pd.read_csv('result/2sBresult.csv')
res2['id'] = res2['id'].apply(lambda x: x.split('_')[0] + '.wav')
prob2['id'] = res2['id']
for col in range(53):
    # prob3['{}_mean'.format(col)]=prob3.groupby('id')[col].transform('mean')
    # del prob3[col]
    prob2[col] = prob2.groupby('id')[col].transform('mean')
prob2 = prob2.drop_duplicates(subset='id')
prob2 = prob2.sort_values(by='id').reset_index(drop=True)





mean_cols = [col for col in prob2.columns if col not in ['id']]
sub = pd.DataFrame(prob2.id)
sub[mean_cols] = 0.52*prob3[mean_cols] + 0.48*prob2[mean_cols]

sub.to_csv('final_result/sub.csv',index=None)
sub['speaker'] = np.argmax(sub[mean_cols].values, axis=1)
sub['fake'] = sub['speaker'].apply(lambda x: 1 if x == 0 else 0)

label_train = pd.read_csv("./data/trainB/train.txt", sep=" ")
idx_spreak = {n: i for n, i in enumerate(label_train["Speaker_ID"].unique())}
spreak_idx = {i: n for n, i in enumerate(label_train["Speaker_ID"].unique())}
sub['speaker'] = sub['speaker'].map(ai_dic)
sub['speaker'] = sub['speaker'].map(idx_spreak)
print(sub['speaker'].value_counts())
print(sub['speaker'].nunique())
sub[['id', 'fake', 'speaker']].to_csv('final_result/en.txt', sep=" ",
                                      header=False, index=False)
