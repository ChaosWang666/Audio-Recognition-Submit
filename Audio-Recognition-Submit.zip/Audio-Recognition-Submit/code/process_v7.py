import pandas as pd
from argparse import ArgumentParser

res = pd.read_csv('result/3sBresult_xing.csv')
res['id'] = res['id'].apply(lambda x: x.split('_')[0] + '.wav')
res = res.groupby('id').agg(lambda x: x.value_counts().index[0]).reset_index()
res.columns = ['id', 'speaker']
res['fake'] = res['speaker'].apply(lambda x: 1 if x == 0 else 0)

label_train = pd.read_csv("./data/trainB/train.txt", sep=" ")
idx_spreak = {n: i for n, i in enumerate(label_train["Speaker_ID"].unique())}
spreak_idx = {i: n for n, i in enumerate(label_train["Speaker_ID"].unique())}
res['speaker'] = res['speaker'].map(idx_spreak)
print(res['speaker'].value_counts())
print(res['speaker'].nunique())
res[['id', 'fake', 'speaker']].to_csv('subB3s_xing.txt', sep=" ",
                                      header=False, index=False)
