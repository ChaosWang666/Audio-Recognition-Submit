# -*- coding: utf-8 -*-

import os
import pandas as pd
import librosa
import librosa.display
import matplotlib.pyplot as plt
import numpy as np
from tqdm import tqdm
import re
from multiprocessing import Pool
from argparse import ArgumentParser

parser = ArgumentParser()

parser.add_argument('--time', dest='time', default=5)
parser.add_argument('--train', dest='train', action='store_true')
parser.add_argument('--trainB', dest='trainB', action='store_true')
parser.add_argument('--test', dest='test', action='store_true')
parser.add_argument('--testB', dest='testB', action='store_true')

args = parser.parse_args()
time = args.time

train = args.train
trainB = args.trainB
test = args.test
testB = args.testB


root_dir=os.path.abspath('..')

label_train = pd.read_csv(root_dir+"/data/train/train.txt", sep=" ")
idx_spreak = {n: i for n, i in enumerate(label_train["Speaker_ID"].unique())}
spreak_idx = {i: n for n, i in enumerate(label_train["Speaker_ID"].unique())}
name2label = {}
for name, speaker_id in zip(label_train['Audio_Name'], label_train['Speaker_ID']):
    if name not in name2label:
        name2label[name] = spreak_idx[speaker_id]

if not os.path.exists(root_dir+'/user_data/melspec'):
    os.mkdir(root_dir+'/user_data/melspec')

if not os.path.exists(root_dir+'/user_data/melspec/{}s'.format(time)):
    os.mkdir(root_dir+'/user_data/melspec/{}s'.format(time))

if not os.path.exists(root_dir+'/user_data/melspec/{}s/train'.format(time)):
    os.mkdir(root_dir+'/user_data/melspec/{}s/train'.format(time))
if not os.path.exists(root_dir+'/user_data/melspec/{}s/test'.format(time)):
    os.mkdir(root_dir+'/user_data/melspec/{}s/test'.format(time))

#if not os.path.exists('data/melspec/{}s/trainB'.format(time)):
#    os.mkdir('data/melspec/{}s/trainB'.format(time))

#if not os.path.exists('data/melspec/{}s/testB'.format(time)):
#    os.mkdir('data/melspec/{}s/testB'.format(time))

for key, value in name2label.items():
    if not os.path.exists(root_dir+'/user_data/melspec/{}s/train/{}'.format(time, value)):
        os.mkdir(root_dir+'/user_data/melspec/{}s/train/{}'.format(time, value))

#for key, value in name2label.items():
#    if not os.path.exists('data/melspec/{}s/trainB/{}'.format(time, value)):
#        os.mkdir('data/melspec/{}s/trainB/{}'.format(time, value))


# Converting audio to Mel scaled power spectrogram Image
def create_melspec(wave_name, fig_name):
    plt.interactive(False)
    clip, sample_rate = librosa.load(wave_name, duration=float(time))
    fig = plt.figure(figsize=[0.72, 0.72])
    ax = fig.add_subplot(111)
    ax.axes.get_xaxis().set_visible(False)
    ax.axes.get_yaxis().set_visible(False)
    ax.set_frame_on(False)
    S = librosa.feature.melspectrogram(y=clip, sr=sample_rate, n_fft=2048, hop_length=512)
    librosa.display.specshow(librosa.power_to_db(S, ref=np.max))

    plt.savefig(fig_name, dpi=400, bbox_inches='tight', pad_inches=0)
    plt.close()
    fig.clf()
    plt.close(fig)
    plt.close('all')
    print(fig_name)
    del clip, sample_rate, fig, ax, S


def multi_melspec(args):
    return create_melspec(*args)


def get_train_figs(fig_root='data/melspec/20s/train', wav_root='data/split_data/train/20s'):
    train_wavs = []
    train_figures = []
    for filename in tqdm(os.listdir(wav_root), desc="create_spectrogram for train.."):
        src = wav_root + '/' + filename
        label_name = re.sub("_chunk\d+", "", filename)
        label = name2label[label_name]
        # print(src,label)
        if not os.path.exists(fig_root + '/' + str(label)):
            os.mkdir(fig_root + '/' + str(label))
        dest = fig_root + '/' + str(label) + '/' + filename.split('.')[0] + '.jpg'
        # create_spectrogram(src, dest)
        train_wavs.append(src)
        train_figures.append(dest)
    return train_wavs, train_figures


def get_test_figs(fig_root='data/melspec/20s/test', wav_root='data/split_data/tets/20s'):
    test_wavs = []
    test_figures = []
    for filename in tqdm(os.listdir(wav_root), desc="create_spectrogram for test.."):
        src = wav_root + '/' + filename
        dest = fig_root + '/' + filename.split('.')[0] + '.jpg'
        # create_spectrogram(src, dest)
        test_wavs.append(src)
        test_figures.append(dest)
    return test_wavs, test_figures


if __name__ == '__main__':
    # split_data("./data/train/", type="train")
    # split_data("./data/test/", type="test")
    if train:
        train_wavs, train_figures = get_train_figs(fig_root=root_dir+'/user_data/melspec/{}s/train'.format(time),
                                                   wav_root=root_dir+'/user_data/split_data/train/{}s'.format(time))
        zip_args = list(zip(train_wavs, train_figures))
        pool = Pool(processes=60)
        pool.map(multi_melspec, zip_args)
        pool.close()

    if test:
        # test melspec
        test_wavs, test_figures = get_test_figs(fig_root=root_dir+'/user_data/melspec/{}s/test'.format(time),
                                                wav_root=root_dir+'/user_data/split_data/test/{}s'.format(time))
        zip_args = list(zip(test_wavs, test_figures))
        pool = Pool(processes=60)
        pool.map(multi_melspec, zip_args)
        pool.close()
    if trainB:
        train_wavs, train_figures = get_train_figs(fig_root='data/melspec/{}s/trainB'.format(time),
                                                   wav_root='data/split_data/trainB/{}s'.format(time))
        zip_args = list(zip(train_wavs, train_figures))
        pool = Pool(processes=28)
        pool.map(multi_melspec, zip_args)
        pool.close()
    if testB:
        testB_wavs, testB_figures = get_test_figs(fig_root='data/melspec/{}s/testB'.format(time),
                                                  wav_root='data/split_data/testB/{}s'.format(time))
        zip_args = list(zip(testB_wavs, testB_figures))
        pool = Pool(processes=28)
        pool.map(multi_melspec, zip_args)
        pool.close()
