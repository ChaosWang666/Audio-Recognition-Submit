#!/bin/bash
python split_data_v3.py --time=2 --train --test
python split_data_v3.py --time=3 --train --test

python extractor_v3.py --time=2 --train --test
python extractor_v3.py --time=3 --train --test

#python train.py --time=2 
#python train.py --time=3 
#python train.py --time=5 

python predict_v3.py --time=2 
python predict_v3.py --time=3

python ensemble.py
